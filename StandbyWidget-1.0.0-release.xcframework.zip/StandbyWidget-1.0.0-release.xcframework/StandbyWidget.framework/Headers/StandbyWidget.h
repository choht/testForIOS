//
//  StandbyWidget.h
//  StandbyWidget
//
//  Created by 양형석 on 5/12/25.
//

#import <Foundation/Foundation.h>

//! Project version number for StandbyWidget.
FOUNDATION_EXPORT double StandbyWidgetVersionNumber;

//! Project version string for StandbyWidget.
FOUNDATION_EXPORT const unsigned char StandbyWidgetVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StandbyWidget/PublicHeader.h>


